package gameplay;

/**
 * Game mode
 * @author 16177
 *
 */
public enum Mode {
	NORMAL, TEST;//MEDIUM, HARD, NIGHTMARE
}
