package tests;

public class QueenTests {

	// public static void main(String[] args) {
	//
	// int pos = 10;
	//
	// Board board = new Board();
	// Queen rook = new Queen(Alliance.WHITE, board, pos);
	// board.chessboard.get(pos).setPiece(rook);
	//
	// board.chessboard.get(13).setPiece(new Bishop(Alliance.WHITE,board,13));
	//
	// for(Integer move : rook.calculateLegalMoves()) {
	// //System.out.println(move);
	// board.chessboard.get(move).setPiece(new Queen(Alliance.BLACK,board,move));
	// }
	// }

}
