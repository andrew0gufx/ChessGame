package tests;

import pieces.Alliance;
import pieces.Pawn;

public class PawnTests{
//	 public static void main(String[] args) {
//
//		 int pos = 5;
//
//		 Board board = new Board();
//		 Pawn pawn = new Pawn(Alliance.WHITE, board, pos);
//		 board.chessboard.get(pos).setPiece(pawn);
//
//		 board.chessboard.get(13).setPiece(new Pawn(Alliance.WHITE,board,14));
//
//		 for(Integer move : pawn.calculateLegalMoves()) {
//		 //System.out.println(move);
//		 board.chessboard.get(move).setPiece(new Pawn(Alliance.BLACK,board,move));
//		 }
//
//	 }
}

