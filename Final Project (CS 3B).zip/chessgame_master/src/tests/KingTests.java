package tests;

import pieces.King;

public class KingTests {

	static King wKing;
	static King bKing;

	public static void main(String[] args) {
		// Board board = new Board();
		//
		// board.testMode = true;
		//
		// King king = new King(Alliance.WHITE, board, 5, 6);
		//
		// King p0 = new King(Alliance.BLACK, board, 2, 4);
		// King p1 = new King(Alliance.WHITE, board, 6, 7);
		//
		// board.getChessboard()[5][6].setPiece(king);
		// board.getChessboard()[1][2].setPiece(p0);
		// board.getChessboard()[7][6].setPiece(p1);
		//
		// Gui gui = new Gui(board);
	}

}
