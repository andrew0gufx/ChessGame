package tests;

public class KnightTests {

	// public static void main(String[] args) {
	//
	// Board board = new Board();
	//
	// board.testMode = true;
	//
	// Knight knight = new Knight(Alliance.WHITE, board, 5, 6);
	//
	// Pawn p0 = new Pawn(Alliance.BLACK, board, 2, 4);
	// Pawn p1 = new Pawn(Alliance.WHITE, board, 6, 7);
	//
	// board.getChessboard()[5][6].setPiece(knight);
	// board.getChessboard()[1][2].setPiece(p0);
	// board.getChessboard()[7][6].setPiece(p1);
	//
	// Gui gui = new Gui(board);
	//
	// }

}
