package tests;

public class GameStateTests {

//	 public static void main(String[] args) {
//
//	 Gui gui = new Gui();
//
//	 Game game = new Game(gui);
//
//	 GameState state = new GameState();
//
//	 ArrayList<Piece> whitePieces = new ArrayList<>();
//	 whitePieces.add(new Rook(Alliance.WHITE, gui.getBoard(), 3, 3));
//
//	 state.setWhitePieces(whitePieces);
//
//	 game.setGameState(state);
//
//	 }

}
