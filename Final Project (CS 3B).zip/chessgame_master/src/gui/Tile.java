package gui;

import java.awt.Color;
import java.awt.Image;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JButton;

import pieces.Alliance;
import pieces.Bishop;
import pieces.King;
import pieces.Knight;
import pieces.Pawn;
import pieces.Piece;
import pieces.Queen;
import pieces.Rook;

/**
 * This class can color the board and pieces, and assign a legitimate range of movement and color.
 * Tiles can also upload an image of a piece, get rows, columns, and tiles, and clear pieces
 * @author GuFX
 *
 */
public class Tile extends JButton {

	private final int row;
	private final int col;

	private double scaleFac = 0.75;
	private Piece piece = null;
	private boolean containsPiece = false;

	public static final Color DARK_TILE = new Color(150, 127, 70);
	public static final Color LIGHT_TILE = new Color(208, 207, 110);
	public static final Color POSS_MOVES = new Color(200, 200, 230);

	public Tile(Color color, int row, int col) {
		this.setBackground(color);
		this.row = row;
		this.col = col;
	}

	/**
	 * this constructor is to make 'ghost' tiles that captured pieces live on
	 * @param row
	 * @param col
	 */
	public Tile(int row, int col) {
		this.row = row;
		this.col = col;
	}

	/**
	 * check if it contains the piece
	 * @return true contain, false not
	 */
	public boolean isPiece() {
		return containsPiece;
	}

	/**
	 * get the piece
	 * @return piece
	 */
	public Piece getPiece() {
		return this.piece;
	}

	/**
	 * clear the piece and the the contains peice to false
	 */
	public void clearPiece() {
		this.piece = null;
		this.setIcon(null);

		containsPiece = false;
	}

	/**
	 * get the row
	 * @return row
	 */
	public int getRow() {
		return this.row;
	}

	/**
	 * get the column
	 * @return column
	 */
	public int getCol() {
		return this.col;
	}

	/**
	 * set up the piece, upload the image
	 * @param piece
	 */
	public void setPiece(Piece piece) {
		this.piece = piece;
		piece.setRow(this.getRow());
		piece.setCol(this.getCol());
		containsPiece = true;

		if (piece instanceof Pawn) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wpawn.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/bpawn.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}

		if (piece instanceof Bishop) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wbishop.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/bbishop.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}

		if (piece instanceof Rook) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wrook.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/brook.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}

		if (piece instanceof Knight) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wknight.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/bknight.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}

		if (piece instanceof King) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wking.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/bking.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}

		if (piece instanceof Queen) {
			if (piece.getAlliance() == Alliance.WHITE) {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/wqueen.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
			else {
				try {
					Image img = ImageIO.read(this.getClass().getResource("ChessPieces/bqueen.png"));
					img = img.getScaledInstance((int) (Gui.WIDTH * scaleFac / Board.BOARD_SIZE),
							(int) ((Gui.HEIGHT * scaleFac - 75) / Board.BOARD_SIZE), Image.SCALE_DEFAULT);
					this.setIcon(new ImageIcon(img));
				}
				catch (Exception ex) {
					System.out.println(ex);
				}
			}
		}
	}
}
