package gui;

import java.awt.BorderLayout;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ButtonGroup;
import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenuBar;
import javax.swing.JPanel;
import javax.swing.JRadioButton;

import gameplay.Game;
import gameplay.Mode;
import pieces.Alliance;

/**
 * This class is to create the buttons, displays chess games, pieces, boards, menus, game mode and statue panels.
 * Users can use menu (reset and undo). "About" button can display a description of the game.
 * @author GuFX
 *
 */
public class Gui implements ActionListener {

	private JFrame mainFrame;
	private JPanel lowerPanel;
	private static JLabel turnLabel;
	private static JLabel checkLabel;

	public JButton aboutButton;
	private JDialog aboutDialog;
	private JLabel aboutLabel;

	private JDialog newGameDialog;
	private JPanel newGamePanel;
	private JPanel player1Panel;
	private JPanel player2Panel;

	private JPanel nightmarePanel;

	private JCheckBox checkBox;
	private JLabel player1;
	private JLabel player2;

	private JComboBox<String> player1Combo;
	private JComboBox<String> player2Combo;

	private JButton okButton;
	private JComboBox<Integer> sizeComboBox;

	private int size;
	private boolean isWhiteComp;
	private boolean isBlackComp;

	private JRadioButton normalChess;
	//private JRadioButton nightmareChess;
	private ButtonGroup buttonGroup;
	//private int[] nigthmareOptions = { 4, 6, 8, 10, 12, 14, 16 };

	private Board board; // extends JPanel!

	private Game game;

	private static String wturn = "White's Turn.";
	private static String bturn = "Black's Turn.";

	private JMenuBar menuBar;
	private JButton undo;
	public JButton newGame;

	public final static int WIDTH = 600;
	public final static int HEIGHT = 675;

	/**
	 * set up the board with menu, piece, board and status panel
	 * @param board
	 */
	public Gui(Board board) {
		// creates the frame
		this.board = board;
		mainFrame = new JFrame();

		// about dialog

		aboutDialog = new JDialog();
		aboutLabel = new JLabel();
		aboutLabel.setPreferredSize(new Dimension(350, 310));
		aboutDialog.add(aboutLabel);
		aboutDialog.setResizable(false);

		aboutButton = new JButton("About");
		aboutButton.addActionListener(this);

		// creates the newGame dialog panel

		player1 = new JLabel("Player 1:   ");
		player2 = new JLabel("Player 2:   ");

		player1Combo = new JComboBox<String>();
		player1Combo.addItem("Human");
		player1Combo.addItem("Computer");
		player1Combo.setSelectedIndex(0);

		player2Combo = new JComboBox<String>();
		player2Combo.addItem("Human");
		player2Combo.addItem("Computer");
		player2Combo.setSelectedIndex(0);

		player1Panel = new JPanel();
		player2Panel = new JPanel();

		player1Panel.setLayout(new BoxLayout(player1Panel, BoxLayout.X_AXIS));
		player2Panel.setLayout(new BoxLayout(player2Panel, BoxLayout.X_AXIS));

		player1Panel.add(player1);
		player1Panel.add(Box.createRigidArea(new Dimension(49, 0)));
		player1Panel.add(player1Combo);

		player2Panel.add(player2);
		player2Panel.add(Box.createRigidArea(new Dimension(49, 0)));
		player2Panel.add(player2Combo);

		normalChess = new JRadioButton("Normal");
		//nighmareChess = new JRadioButton("nightmare!");
		buttonGroup = new ButtonGroup();
		normalChess.setSelected(true);

		nightmarePanel = new JPanel();
		nightmarePanel.setLayout(new BoxLayout(nightmarePanel, BoxLayout.X_AXIS));

//		nightmarePanel.add(normalChess);
//		nightmarePanel.add(Box.createRigidArea(new Dimension(20, 0)));
//		buttonGroup.add(normalChess);
//		normalChess.addActionListener(this);

		okButton = new JButton("OK");
		okButton.addActionListener(this);
		okButton.setAlignmentX(newGameDialog.CENTER_ALIGNMENT);

		newGamePanel = new JPanel();
		newGamePanel.setLayout(new BoxLayout(newGamePanel, BoxLayout.Y_AXIS));
		newGamePanel.setPreferredSize(new Dimension(190, 160));

		newGamePanel.add(player1Panel);
		newGamePanel.add(player2Panel);
		newGamePanel.add(okButton);

		board.setGui(this);

		newGame = new JButton("New Game");
		undo = new JButton("Undo");

		newGame.addActionListener(this);

		menuBar = new JMenuBar();
		mainFrame.setJMenuBar(menuBar);
		mainFrame.setTitle("Chess Game");
		menuBar.add(aboutButton);
		menuBar.add(newGame);
		menuBar.add(undo);

		lowerPanel = new JPanel();
		turnLabel = new JLabel();
		checkLabel = new JLabel();

		lowerPanel.setPreferredSize(new Dimension(WIDTH, 40));

		lowerPanel.setLayout(new BoxLayout(lowerPanel, BoxLayout.X_AXIS));
		lowerPanel.add(turnLabel);
		lowerPanel.add(Box.createRigidArea(new Dimension(WIDTH - 350, 0)));
		lowerPanel.add(checkLabel);

		turnLabel.setFont(new Font("TimesRoman", Font.PLAIN, 20));
		checkLabel.setFont(new Font("TimesRoman", Font.PLAIN, 20));

		// adds panels to frame and builds frame

		mainFrame.getContentPane().add(BorderLayout.CENTER, board);
		mainFrame.getContentPane().add(BorderLayout.SOUTH, lowerPanel);

		mainFrame.setSize(WIDTH, HEIGHT);
		mainFrame.setVisible(true);
		mainFrame.setResizable(false);
		mainFrame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

	}

	/**
	 * get the board
	 * @return board
	 */
	public Board getBoard() {
		return board;
	}

	/**
	 * update the status panel, white turn or black turn
	 * check or not
	 * @param bool check the turns
	 */
	public void updateLabels(boolean bool) {

		// turn label
		if (Game.turn == Alliance.WHITE) {
			turnLabel.setText(wturn);
		} else {
			turnLabel.setText(bturn);
		}

		// test for check & checkmate
		if (bool) {
			if (game.isCheckMate()) {
				checkLabel.setText("Checkmate!");
			}

			else if (game.inCheck()) {
				checkLabel.setText("Check!");
			} else {
				checkLabel.setText("");
			}
		}

	}

	/**
	 * new Game(reset) function, and description of the game
	 */
	@Override
	public void actionPerformed(ActionEvent e) {

		if (e.getSource() == aboutButton) {
			aboutDialog.setTitle("About");
			aboutDialog.setModal(false);
			aboutLabel.setText("<html> "
					+ "<p>This is a simple chess program for two human players, human vs AI part is not completed yet. "
					+ " <p> The program based on chess rules, includes features such as checking for check and checkmate, "
					+ "promoting pawns to queens, and allowing players to undo moves (no redo at the moment).<br>"
					+ " At this stage the game does not allow castling or en passant - to be added!<br>"
					+ "This program also have NewGame(reset) function, the status panel is on the bottom</p><br>"
					+ "Have fun!");

			aboutDialog.pack();
			aboutDialog.setLocationRelativeTo(mainFrame);
			aboutDialog.setVisible(true);

		}

		else if (e.getSource() == newGame) {

			newGameDialog = new JDialog(mainFrame);
			newGameDialog.add(newGamePanel);
			newGameDialog.setTitle("New Game");
			newGameDialog.setResizable(false);
			newGameDialog.setModal(true);
			newGameDialog.pack();
			newGameDialog.setLocationRelativeTo(mainFrame);

			newGameDialog.setVisible(true);

		} else if (e.getSource() == okButton) {
			board.clearBoard();
			mainFrame.remove(board);
			board = null;

			if (player1Combo.getSelectedIndex() == 0) {
				isWhiteComp = false;
			} else {
				isWhiteComp = true;
			}

			if (player2Combo.getSelectedIndex() == 0) {
				isBlackComp = false;
			} else {
				isBlackComp = true;
			}

			if (normalChess.isSelected()) {
				board = new Board(8);
				board.setGui(this);
				mainFrame.getContentPane().add(BorderLayout.CENTER, board);

				game = new Game(this, Mode.NORMAL, 8, isWhiteComp, isBlackComp);
				newGameDialog.dispose();
			} else {
				size = (int) sizeComboBox.getSelectedItem();
				board = new Board(size);
				board.setGui(this);
				mainFrame.getContentPane().add(BorderLayout.CENTER, board);

				newGameDialog.dispose();
			}
		} else {
			if (normalChess.isSelected()) {
				sizeComboBox.setEnabled(false);
				checkBox.setEnabled(false);
				;
			} else {
				sizeComboBox.setEnabled(true);
				checkBox.setEnabled(true);

			}
		}
	}

	/**
	 * set the game
	 * @param game
	 */
	public void setGame(Game game) {
		this.game = game;
		undo.addActionListener(game);
	}
}