package gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import gameplay.Game;
import gameplay.Mode;
import pieces.Alliance;
import pieces.Pawn;
import pieces.Queen;

/**
 * This class displays the chess board, which can be printed again when the user uses the reset function.
 * You can view the game state to see if the game is over. Clear the board. Check the AI.
 * @author GuFX
 *
 */
public class Board extends JPanel implements ActionListener {

	public static int BOARD_SIZE;
	private boolean tilePainter = true;

	private Game game;
	private Gui gui;
	//private boolean aiRunning = false;
	private boolean isTileSelected = false;

	private Tile selectedTile;
	private Tile clickedTile;
	private Tile[][] chessboard;


	/**
	 * constructor, print the board with default size
	 * @param boardSize
	 */
	public Board(int boardSize) {

		BOARD_SIZE = boardSize;

		chessboard = new Tile[BOARD_SIZE][BOARD_SIZE];

		this.setPreferredSize(new Dimension(WIDTH, HEIGHT - 75));

		this.setLayout(new GridLayout(BOARD_SIZE, BOARD_SIZE));

		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {

				// adds tiles to chess board array
				if (tilePainter) {
					chessboard[i][j] = new Tile(Tile.LIGHT_TILE, i, j);
				}
				else {
					chessboard[i][j] = new Tile(Tile.DARK_TILE, i, j);
				}
				if (j != BOARD_SIZE - 1) {
					tilePainter = !tilePainter;
				}

				// adds actionListener to each tile
				chessboard[i][j].addActionListener(this);

				// adds each tile to the panel (this)
				this.add(chessboard[i][j]);
			}
		}
	}

	/**
	 * repaint the board, call it when need to undo or reset
	 */
	private void repaintBoard() {
		for (int i = 0; i < BOARD_SIZE; i++) {
			for (int j = 0; j < BOARD_SIZE; j++) {

				// repaints tiles (eg. after highlighting possible moves)
				if (tilePainter) {
					chessboard[i][j].setBackground(Tile.LIGHT_TILE);
				}
				else {
					chessboard[i][j].setBackground(Tile.DARK_TILE);
				}
				if (j != BOARD_SIZE - 1) {
					tilePainter = !tilePainter;
				}

			}
		}
	}

	/**
	 * get the game
	 * @return game
	 */
	public Game getGame() {
		return game;
	}

	/**
	 * set the game
	 * @param game
	 */
	public void setGame(Game game) {
		this.game = game;
	}

	/**
	 * get the position of the board
	 * @return position of the board
	 */
	public Tile[][] getChessboard() {
		return chessboard;
	}

	/**
	 *check the game status,
	 */
	@Override
	public void actionPerformed(ActionEvent e) {
		if (!game.isGameOver()) {
			if (e.getSource() instanceof Tile) {
				clickedTile = (Tile) e.getSource();

				if (!isTileSelected) {
					// if there is a tile there with non-empty possible moves
					if (clickedTile.isPiece() && !clickedTile.getPiece().calculateLegalMoves().isEmpty()) {
						// if we are in test mode OR it is that pieces turn to play
						if (game.getMode() == Mode.TEST || clickedTile.getPiece().getAlliance() == Game.turn) {

							// selects the tile and displays possible moves
							selectedTile = clickedTile;
							isTileSelected = true;
							for (Tile move : selectedTile.getPiece().calculateLegalMoves()) {
								move.setBackground(Tile.POSS_MOVES);
							}
						}
					}
					// otherwise nothing happens
				}
				else {
					// i.e. repaint the possibleMoves tiles
					repaintBoard();

					if (selectedTile.getPiece().calculateLegalMoves().contains(clickedTile)) {

						if (game.getMode() != Mode.TEST) {
							if (clickedTile.isPiece()) {
								// set capturedPiece position to off the board
								clickedTile.getPiece().setRow(BOARD_SIZE + 1);
								clickedTile.getPiece().setCol(BOARD_SIZE + 1);

							}
						}

						// move the piece

						clickedTile.setPiece(selectedTile.getPiece());
						clickedTile.getPiece().setRow(clickedTile.getRow());
						clickedTile.getPiece().setCol(clickedTile.getCol());

						// clears the old tile
						selectedTile.clearPiece();

						// check for promotion
						if (clickedTile.getPiece() instanceof Pawn) {
							if (clickedTile.getPiece().getAlliance() == Alliance.WHITE) {
								if (clickedTile.getPiece().getRow() == 0) {
									clickedTile.setPiece(new Queen(Alliance.WHITE, this, clickedTile.getRow(),
											clickedTile.getCol()));
									game.getWhitePlayer().getPieces().add(clickedTile.getPiece());
									game.getAllPieces().add(clickedTile.getPiece());
								}
							}
							else {
								if (clickedTile.getPiece().getRow() == 1) {
									clickedTile.setPiece(new Queen(Alliance.BLACK, this, clickedTile.getRow(),
											clickedTile.getCol()));
									game.getBlackPlayer().getPieces().add(clickedTile.getPiece());
									game.getAllPieces().add(clickedTile.getPiece());
								}
							}

						}
						game.updatePositions();

						game.numOfMoves++;

						Game.changeTurn();

					}

					isTileSelected = false;
					e.setSource(null);

					// this includes checking for checkmate (via isCheckMate() in Game)
					gui.updateLabels(true);

				}
			}
		}
	}

	/**
	 * clear the board,
	 */
	public void clearBoard() {
		for (int i = 0; i < Board.BOARD_SIZE; i++) {
			for (int j = 0; j < Board.BOARD_SIZE; j++) {
				chessboard[i][j].clearPiece();
			}
		}

	}

	/**
	 * set up the GUI
	 * @param gui
	 */
	public void setGui(Gui gui) {
		this.gui = gui;
	}

}