package pieces;

public enum Alliance {
	BLACK, WHITE;
}
